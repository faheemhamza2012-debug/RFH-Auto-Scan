package com.rfh.autoscan;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.bluetooth.*;
import android.content.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView status, rpm, speed, fuel, coolant, log;
    EditText host, port;
    BluetoothSocket btSocket;
    volatile boolean running=false;
    final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(20,20,20));
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(16,16,16,16); root.setBackgroundColor(Color.rgb(28,29,32));
        TextView title=new TextView(this); title.setText("RFH AUTO SCAN"); title.setTextSize(26); title.setTextColor(Color.WHITE); title.setGravity(17); root.addView(title);
        status=label("Not connected — choose Bluetooth or Wi-Fi"); root.addView(status);
        LinearLayout row=new LinearLayout(this);
        Button bt=button("Bluetooth"); Button wifi=button("Wi-Fi"); row.addView(bt,new LinearLayout.LayoutParams(0,-2,1)); row.addView(wifi,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);
        host=new EditText(this); host.setSingleLine(); host.setHint("Wi-Fi adapter IP (often 192.168.0.10)"); host.setText("192.168.0.10"); root.addView(host);
        port=new EditText(this); port.setSingleLine(); port.setInputType(2); port.setHint("Port (often 35000)"); port.setText("35000"); root.addView(port);
        LinearLayout gauges=new LinearLayout(this); gauges.setOrientation(1);
        LinearLayout r1=new LinearLayout(this), r2=new LinearLayout(this);
        rpm=gauge("RPM"); speed=gauge("Speed"); fuel=gauge("Fuel %"); coolant=gauge("Coolant °C");
        r1.addView(rpm,new LinearLayout.LayoutParams(0,170,1)); r1.addView(speed,new LinearLayout.LayoutParams(0,170,1));
        r2.addView(fuel,new LinearLayout.LayoutParams(0,170,1)); r2.addView(coolant,new LinearLayout.LayoutParams(0,170,1));
        gauges.addView(r1); gauges.addView(r2); root.addView(gauges);
        Button stop=button("Disconnect"); root.addView(stop);
        TextView note=label("Live OBD-II PIDs: 010C RPM, 010D speed, 012F fuel %, 0105 coolant. ECU support varies by vehicle."); root.addView(note);
        log=label("Waiting for connection…"); root.addView(log);
        setContentView(root);
        bt.setOnClickListener(v->connectBluetooth());
        wifi.setOnClickListener(v->connectWifi());
        stop.setOnClickListener(v->{running=false; try{if(btSocket!=null)btSocket.close();}catch(Exception ignored){}; status.setText("Disconnected");});
    }
    TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.LTGRAY);t.setTextSize(14);t.setPadding(4,8,4,8);return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    TextView gauge(String name){TextView t=new TextView(this);t.setText(name+"\n—");t.setTextColor(Color.WHITE);t.setTextSize(21);t.setGravity(17);t.setBackgroundColor(Color.rgb(48,50,55));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,160,1);p.setMargins(4,4,4,4);return t;}
    void connectBluetooth(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT")!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT"},77);status.setText("Allow Nearby devices, then tap Bluetooth again.");return;}
        new Thread(()->{try{
            BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter(); if(a==null)throw new Exception("Bluetooth not available");
            Set<BluetoothDevice> ds=a.getBondedDevices(); BluetoothDevice target=null;
            for(BluetoothDevice d:ds){String n=d.getName(); if(n!=null && (n.toLowerCase().contains("obd")||n.toLowerCase().contains("elm")||n.toLowerCase().contains("car"))){target=d;break;}}
            if(target==null)throw new Exception("Pair the ANCEL/ELM327 in Android Bluetooth settings first; then retry.");
            btSocket=target.createRfcommSocketToServiceRecord(SPP); a.cancelDiscovery(); btSocket.connect();
            startReader(btSocket.getInputStream(),btSocket.getOutputStream(),"Bluetooth "+target.getName());
        }catch(Exception e){runOnUiThread(()->status.setText("Bluetooth: "+e.getMessage()));}}).start();
    }
    void connectWifi(){
        new Thread(()->{try{Socket s=new Socket();s.connect(new InetSocketAddress(host.getText().toString().trim(),Integer.parseInt(port.getText().toString().trim())),5000);startReader(s.getInputStream(),s.getOutputStream(),"Wi-Fi OBD");}catch(Exception e){runOnUiThread(()->status.setText("Wi-Fi: "+e.getMessage()));}}).start();
    }
    void startReader(InputStream in,OutputStream out,String label){
        running=true; runOnUiThread(()->status.setText("Connected: "+label));
        new Thread(()->{try{
            for(String init:new String[]{"ATZ","ATE0","ATL0","ATS0","ATH0","ATSP0"}){out.write((init+"\r").getBytes());out.flush();Thread.sleep(450);while(in.available()>0)in.read();}
            while(running){
                readPid(in,out,"010C",0); readPid(in,out,"010D",1); readPid(in,out,"012F",2); readPid(in,out,"0105",3); Thread.sleep(250);
            }
        }catch(Exception e){runOnUiThread(()->status.setText("Connection stopped: "+e.getMessage()));running=false;}}).start();
    }
    void readPid(InputStream in,OutputStream out,String cmd,int which)throws Exception{
        out.write((cmd+"\r").getBytes());out.flush();Thread.sleep(180);
        StringBuilder sb=new StringBuilder();long end=System.currentTimeMillis()+650;
        while(System.currentTimeMillis()<end){while(in.available()>0){int c=in.read();if(c>0)sb.append((char)c);}if(sb.indexOf(">")>=0)break;Thread.sleep(20);}
        String hex=sb.toString().replaceAll("[^0-9A-Fa-f]","").toUpperCase(Locale.US);
        int idx=hex.indexOf("41"+cmd.substring(2).toUpperCase(Locale.US)); if(idx<0||hex.length()<idx+6)return;
        try{
            int a=Integer.parseInt(hex.substring(idx+4,idx+6),16), value=a;
            if(which==0){if(hex.length()<idx+8)return;int b=Integer.parseInt(hex.substring(idx+6,idx+8),16);value=((a*256)+b)/4;}
            final String val;
            if(which==0)val=value+"";
            else if(which==1)val=a+" km/h";
            else if(which==2)val=Math.round(a*100.0/255.0)+"%";
            else val=(a-40)+"°C";
            runOnUiThread(()->{TextView t=which==0?rpm:which==1?speed:which==2?fuel:coolant;t.setText((which==0?"RPM":which==1?"Speed":which==2?"Fuel %":"Coolant °C")+"\n"+val);log.setText("Last PID: "+cmd+" → "+val);});
        }catch(Exception ignored){}
    }
}
