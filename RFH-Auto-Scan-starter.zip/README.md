# RFH Auto Scan (starter)

Android starter app for ELM327-compatible OBD-II adapters. Initial target: Suzuki Wagon R 2021.

Current starter features:
- Bluetooth Classic SPP connection to a paired ELM327 adapter
- Wi-Fi TCP connection (adapter IP/port entered in app)
- Four live OBD-II PID tiles: RPM, speed, fuel level %, coolant temperature

Important limitations:
- This is an early starter build, not a validated release.
- Vehicle-specific Suzuki modules (K-Line, ABS, SRS, BCM, etc.) are not implemented.
- Fuel economy/range, DTC workflows, and manufacturer-specific data are not yet implemented.
- PID availability and adapter compatibility vary. Test while parked; never operate the phone while driving.
